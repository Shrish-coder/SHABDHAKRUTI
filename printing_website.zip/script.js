document.getElementById('contactForm').addEventListener('submit', function (e) {
  e.preventDefault();
  document.getElementById('responseMessage').textContent = "Thanks! We'll get back to you soon.";
  this.reset();
});
